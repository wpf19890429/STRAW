straw<-function(pv, pis, ks.vec, q)
{

  # the input
  # pv: the p-values
  # pis: conditional probabilities
  # q: the FDR level
  # ks.vec: vector of weight
  # the output
  # nr: the number of hypothesis to be rejected
  # th: the shifted p-value threshold
  # de: the decision rule


  #### shifted p_value
  m<-length(pv)
  j_new<-0
  est_ks<-1
  p_adapted_new<-rep(0,m)
  ranked_p_adapted_new<-rep(0,m)
  if (missing(ks.vec))
    ks.vec=seq(0.5,5,0.25)

  for (ks in ks.vec)
  {
    p_adapted<-pv*((1-pis)/pis)^(1/ks)
    ranked_p_adapted<-p_adapted[order(p_adapted)]
    ranking<-order(p_adapted)
    for(j in m:1)
    {
      c_star<-ranked_p_adapted[j]*(pis[ranking]/(1-pis[ranking]))^(1/ks)
      FDP_value<-sum(c_star*(1-pis[ranking]),na.rm=TRUE)/j
      if(FDP_value<q)
        break
    }
    if (j>j_new)
    {
      j_new<-j
      est_ks<-ks
      p_adapted_new<-p_adapted
      ranked_p_adapted_new<-ranked_p_adapted
    }
  }
  th<-ranked_p_adapted_new[j_new]
  pv.adapted.de<-rep(0, m)
  pv.adapted.de[which(p_adapted_new<th)]<-1
  nr<-sum(pv.adapted.de)

  return(list(th=th, nr=nr, de=pv.adapted.de, est_ks=est_ks))
}
