disvec_2Dfunc<-function(dims, s)
{
  # disvec computes the distances of all points on a m1 times m2 spatial domain to a point s
  ## Arguments:
  # dims=c(d1, d2): the dimensions
  # s=c(s1, s2): a spatial point
  ## Values:
  # a vector of distances

  m<-dims[1]*dims[2]
  dis.vec<-rep(0, m)
  for(i in 1:dims[1])
  {
    dis.vec[((i-1)*dims[2]+1):(i*dims[2])]<-sqrt((i-s[1])^2+(1:dims[2]-s[2])^2)
  }
  return(dis.vec)
}
