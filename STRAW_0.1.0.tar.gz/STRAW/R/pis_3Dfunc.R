pis_3Dfunc<- function(x.3D,h)
{
  #x: 3D array
  #h: the bandwidth of kernel functions
  #pis.hat: local sparsity level
  dims<-dim(x.3D)
  m<-dims[1]*dims[2]*dims[3]
  pis.hat <- array(0,dims)
  Lfdr<-locfdr(x.3D, bre = 120, df = 7, pct = 0, pct0 = 1/4, nulltype = 0,
               type =0, plot = 0, main = " ", sw = 0)$fdr
  for (i in 1:dims[1])
  {
    for (j in 1:dims[2])
    {
      for (k in 1:dims[3])
      {
        s<-c(i,j,k)
        dis.vec<-disvec_3Dfunc(dims, s)
        kht<-dnorm(dis.vec, 0, h)
        kht[which(dis.vec>h)]<-0
        pis.hat[i,j,k]<-sum(kht*(1-Lfdr))/sum(kht)
      }
    }
  }
  c(pis.hat)
}
