pis_1Dfunc<-function(x,h) {
  #x: the statistic vector
  #h: the bandwidth of kernel functions
  #pis.hat: local sparsity level
  require(locfdr)
  m <- length(pv)
  Lfdr<-locfdr(x, bre = 120, df = 7, pct = 0, pct0 = 1/4, nulltype = 0,
               type =0, plot = 0, main = " ", sw = 0)$fdr
  pis.hat<-rep(0, m)
  s <- 1:m # auxiliary variable
  for (t in 1:m)
  {
    dis.vec<-abs(s-t)
    kht<-dnorm(dis.vec, 0, h)
    kht[which(abs(s-t)>h)]<-0
    pis.hat[t]<-sum(kht*(1-Lfdr))/sum(kht)
  }
  pis.hat
}
