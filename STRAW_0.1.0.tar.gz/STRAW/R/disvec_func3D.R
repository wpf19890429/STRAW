disvec_3Dfunc<-function(dims, s)
{
  # disvec computes the distances of all points on a m1 times m2 spatial domain to a point s
  ## Arguments:
  # dims=c(d1, d2, d3): the dimensions
  # s=c(s1, s2, s3): a spatial point
  ## Values:
  # a vector of distances

  m<-dims[1]*dims[2]*dims[3]
  dis.vec<-rep(0, m)
  loc<-0
  for(k in 1:dims[3])
  {
    for (j in 1:dims[2])
    {
      for(i in 1:dims[1])
      {
        loc<-loc+1
        dis.vec[loc]<-sqrt((i-s[1])^2+(j-s[2])^2+(k-s[3])^2)
      }
    }
  }
  return(dis.vec)
}
