pis_2Dfunc<-function(x.2D,h) {
  #x: the statistic matrix
  #h: the bandwidth of kernel functions
  #pis.hat: local sparsity level
  require(locfdr)
  dims<-dim(x.2D)
  m<-dims[1]*dims[2]
  pis.hat <- matrix(0,dims[1],dims[2])
  Lfdr<-locfdr(x.2D, bre = 120, df = 7, pct = 0, pct0 = 1/4, nulltype = 0,
               type =0, plot = 0, main = " ", sw = 0)$fdr
  for (i in 1:dims[1]) {
    for (j in 1:dims[2]) {
      s<-c(i, j)
      dis.vec<-disvec_2Dfunc(dims, s)
      kht<-dnorm(dis.vec, 0, h)
      kht[which(dis.vec>h)]<-0
      pis.hat[i,j]<-sum(kht*(1-Lfdr))/sum(kht)
    }
  }
  return(c(pis.hat))
}
